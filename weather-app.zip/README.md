# Weather App ☀️🌦️

A simple Python application to fetch and display the current weather information for a given city using OpenWeatherMap API.

## Features
- Search weather by city name
- Displays temperature, humidity, and weather description
- Handles invalid city names gracefully

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/weather-app.git
   cd weather-app
   ```

2. Install required packages:
   ```bash
   pip install -r requirements.txt
   ```

3. Get a free API Key:
   - Go to [OpenWeatherMap](https://openweathermap.org/api) and sign up for a free account.
   - Replace `'your_api_key_here'` in `app.py` with your API key.

4. Run the application:
   ```bash
   python app.py
   ```

## License
Open-source and free to use.